
<footer id="footer">
  This is where contact info should be
</footer>

</div>
<!-- End of "page container" -->
  <?php wp_footer(); ?>
</body>
</html>
